
using TypedTables, Statistics, DelimitedFiles, Peaks
using DifferentialEquations, Optimization, OptimizationPolyalgorithms, SciMLSensitivity
using ForwardDiff, ScatteredInterpolation
using StaticArrays
using DelimitedFiles

N = parse(Int,ARGS[1]); 

data = readdlm("samples.csv", ',', Float64)
Pn, tau_HTs, kes, gain_Rep, gain_HTs, gain_Cvs = data[N, :]

dt              = 0.1;                                # time step
T_init          = 0;                                  # initial time
T_max           = 700;                                # duration of simulation
tRange          = T_init : dt : T_max;                # time range
tspan           = (T_init, T_max);

function model(dPdt:: Vector, P:: Vector, h, p, t)
    # unpack parameter vector 

    Pn, tau_HTs, kes, gain_Rep, gain_HTs, gain_Cvs = p

    ELVmax          = Float32(1.75);                              # maximum elastance for LV  
    ELVmin          = Float32(0.10);                              # Shi
    ERVmax          = Float32(0.52); 
    ERVmin          = Float32(0.06);                               

    # Atria
    ELAmax        = Float32(0.5);                                
    ELAmin        = Float32(0.27);                                    
    ERAmax        = Float32(0.24);                                 
    ERAmin        = Float32(0.12);

    # Mechanical parameters
    RsA = Float32(2.0);
    ReA = Float32(1.5);
    Rpul = Float32(0.04);
    CAo = Float32(0.28) #Ursino
    RAo = Float32(0.01)#Ursino
    CsA = Float32(2.05) #Ursino
    CsV = Float32(61.11) #Ursino
    RsV = Float32(0.038) #Ursino
    RAo2 = Float32(0.001)
    CeA = Float32(1.67)
    CeV = Float32(50.00) #20
    reV = Float32(0.016)
    CpulA = Float32(5.80) 
    CpulV = Float32(25.37)
    Rvv = Float32(0.0056)   

    # Regulation parameters (all from Ursino) according to Table 3
    # Afferent pathway
    #Pn              = 92;                            # mmHg, setpoint pressure (value of intrasinus pressure at the central point of sigmoid)
    ka              = Float32(11.758);                        # mmHg, parameter related to a slope
    fmin            = Float32(2.52);                          # spikes/sec, minimum frequency, sigmoid limiter
    fmax            = Float32(47.78);                         # spikes/sec, maximum frequency, sigmoid limiter
    tau_z           = Float32(6.37);                          # sec, time constant for the real zero in a linear dynamic block
    tau_p           = Float32(2.076);                         # sec, time constant for the real pole in a linear dynamic block
    # Sympathetic efferent pathway
    fes_inf         = Float32(2.10);                          # spikes/sec, frequency for infinity
    fes_0           = Float32(16.11);                         # spikes/sec, frequency for the absence of innervation
    fes_min         = Float32(2.66);                          # spikes/sec, minimum frequency for sympathetic efferent path
    #kes             = 2*Float32(0.0675);                        # sec, parameter for exponential function
    # Vagal efferent pathway
    fev_0           = Float32(3.2);                           # spikes/sec
    fev_inf         = 6.3;                           # spikes/sec
    fcs_0           = Float32(25);                            # spikes/sec
    kev             = Float32(7.06);                          # spikes/sec

    # Regulation gains
    gain_ELV        = Float32(0.475);                         # maximum left ventricular elastance control
    gain_ERV        = Float32(0.282);                         # maximum left ventricular elastance control
    #gain_Rep        = Float32(3);                         # splanchnic systemic resistance control
    gain_Rsp        = 1.31*gain_Rep;                         # splanchnic systemic resistance control

    #gain_HTs        = -0.47#-2.9031 * gain_HTv - 0.1485# -2.9031 * gain_HTv - 0.1485;                          # heart period sympathetic control
    gain_HTv        = 0.09;                          # heart period vagal control
    #gain_Cv         = Float32(-80);                           # -199 venous unstressed volume  
    #gain_Cvs = 184 * gain_HTs - 28.16
    gain_Cv = 0.5*gain_Cvs


    # Effectors
    tau_ELV         = Float32(8);
    tau_ERV         = Float32(8);                      
    tau_Rsp         = Float32(6);
    tau_Rep         = Float32(6);
    #tau_HTs = 60.0
    tau_HTv = 0.75* tau_HTs;
    tau_Cv = Float32(20);
    tau_Cvs = Float32(20);

    # Heart data
    HT0             = Float32(0.83);                             # heart period: inital value (Ursino, table 2)

    rav             = Float32(0.005);                            # copied from rmv
    rmv             = Float32(0.005);                            # Ursino
    rtv             = Float32(0.005);                            # Ursino
    rpv             = Float32(0.005);                            # copied from rtv
    tauinitV       = Float32(0.00);
    tauS1V         = Float32(0.3);       
    tauS2V         = Float32(0.45);                                     
    tauinitA     = Float32(0.90);
    tauS1A       = Float32(0.96);       
    tauS2A       = Float32(1.00);        
    alpha = 2 * 1000/pi
    alpha2 = 2 * 1000/pi

    # LBNP
    t_start=Float32(280)
    t_2=Float32(310)
    t_3=Float32(520)
    t_4=Float32(550)
    Pmax = Float32(60)


    ###
    # MODEL PART
    P[31]    = RsA  + P[14] 
    P[32]    = ReA  + P[15] 
    
    if (t-P[36]) > 0  
        P[30] = (HT0 + P[13] + P[18])  
        P[33] = (ELVmax + P[16])  
        P[34] = (ERVmax + P[17])                                                # if simulation reaches the end of the beat, change the value of heart period, elastance, systemic resistance
        P[35] = t;
        P[36] = P[36] + P[30]                                       # ... and change the time of next end of the beat because of the heart period adjustment
    end

    # delays taken from Ursino 1998 :: hard coded 
    hist1=h(P, t-2)[12]
    hist2 =h(P, t-5)[12]
    hist3=h(P, t-0.2)[12]
    
    ElocalLV, dEdtlocalLV    = ShiCosineElastance(t-P[35], tauinitV, tauS1V, tauS2V, P[33] ,ELVmin, 60/P[30])         # elastance calculations - LV
    ElocalRV, dEdtlocalRV    = ShiCosineElastance(t-P[35], tauinitV, tauS1V, tauS2V, P[34] ,ERVmin, 60/P[30])         # elastance calculations - LV
    ElocalRA, dEdtlocalRA    = ShiCosineElastanceATRIA(t-P[35], tauinitA, tauS1A, tauS2A, ERAmax, ERAmin, 60/P[30])         # elastance calculations - LV
    ElocalLA, dEdtlocalLA    = ShiCosineElastanceATRIA(t-P[35], tauinitA, tauS1A, tauS2A, ELAmax, ELAmin, 60/P[30])         # elastance calculations - LV

    # new variables for pressures in the system, to make the set of ODE more clear
    iAV                      = Valve(P[1]-P[2]  ,rav);                                                                         # flow through aortic valve
    iMV                      = Valve(P[11]-P[1] ,rmv);                                                                         # flow through mitral valve
    iTV                      = Valve(P[7]-P[8]  ,rtv);
    iPV                      = Valve(P[8]-P[9]  ,rpv);
    iEV                      = Valve(P[6]-P[7]  ,reV);      # venous valves 

    # Ursino : afferent spiking 
    fcsSym1        = (fmin + fmax * exp((hist1-Pn)/ka)) / (1+exp((hist1-Pn)/ka));
    fcsSym2        = (fmin + fmax * exp((hist2 -Pn)/ka)) / (1+exp((hist2 -Pn)/ka));
    fcsVagHT        = (fmin + fmax * exp((hist3-Pn)/ka)) / (1+exp((hist3-Pn)/ka));

    # Ursino: efferent sympathetic frequency calculation
    fesSymHT        = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym1 );
    fesSymRsp       = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym1);
    fesSymRep       = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym1);
    fesSymELV       = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym1);
    fesSymERV       = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym1);
    fesSymCv        = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym2 );
    fesSymCs        = fes_inf   .+ (fes_0 - fes_inf) .*  exp(-kes*fcsSym2 );

    # Ursino: efferent parasympathetic (vagal) frequency calculation
    fevPsymHT       = (fev_0 + fev_inf .* exp((fcsVagHT-fcs_0)/kev))./(1+exp((fcsVagHT-fcs_0)/kev));
  
    # Effector control inputs                                                        
    if fesSymHT - fes_min >= 0
        sigmaHTs          = gain_HTs    .*   log(fesSymHT  .- fes_min .+ 1);
    else 
        sigmaHTs = 0;
    end
    
    if fesSymRsp - fes_min >= 0
        sigmaRsp          = gain_Rsp    .*   log(fesSymRsp  .- fes_min .+ 1);
    else 
        sigmaRsp = 0;
    end

    if fesSymRep - fes_min >= 0
        sigmaRep          = gain_Rep    .*   log(fesSymRep  .- fes_min .+ 1)   
    else 
        sigmaRep = 0
    end

    if fesSymELV - fes_min >= 0
        sigmaELV          = gain_ELV    .*   log(fesSymELV  .- fes_min .+ 1)  
    else 
        sigmaELV = 0;
    end

    if fesSymERV - fes_min >= 0
        sigmaERV          = gain_ERV    .*   log(fesSymERV  .- fes_min .+ 1)   
    else 
        sigmaERV = 0;
    end

    sigmaHTv          = gain_HTv    .*   fevPsymHT;
    
    if fesSymCv - fes_min >= 0
        sigmaCv           = gain_Cv     .*   log(fesSymCv   .- fes_min .+ 1)   
    else 
        sigmaCv = 0;
    end

    if fesSymCs - fes_min >= 0
        sigmaCs           = gain_Cvs     .*  log(fesSymCs   .- fes_min .+ 1)  
    else 
        sigmaCs = 0;
    end

    # LBNP profile
    LBNP = 0 * (t <= t_start) + 
    (Pmax/2 * (1 - cos(pi*((t-t_start)/(t_2-t_start)))))*(t > t_start)*(t<=t_2) +
    Pmax * (t > t_2)* (t <= t_3) +
    (-Pmax/2 * (1 + cos(pi*((t-t_3)/(t_3-t_4)))))*(t > t_3)*(t<=t_4) +
    0 * (t > t_4)
    source =  (-Pmax/(2*(t_2-t_start)) * pi*(sin(pi*((t-t_start)/(t_2-t_start)))))     *(t > t_start)  *(t <= t_2) +
                (Pmax/(2*(t_4-t_3)) * pi*(sin(pi*((t-t_3)/(t_4-t_3)))))                *(t > t_3)      *(t <= t_4)    
    
    # Flows
    Q1              = iAV;
    Q2              = (P[2]-P[3])/RAo -Q1
    Qs1 = (P[2]-P[3])/RAo - (P[3]-P[5])/RAo2
    Q3              = (P[3]-P[4])/P[31] - (P[2]-P[3])/RAo + (P[3]-P[5])/RAo2
    Q4              = (P[4]-P[7])/RsV - (P[3]-P[4])/P[31]
    Q5              = (P[5]-P[6])/P[32] - (P[3]-P[5])/RAo2
    Q6              = iEV - (P[5]-P[6])/P[32]
    Q7              = iTV
    Q8              = iPV
    Q9              = (P[9]-P[10])/Rpul - Q8
    Q10             = (P[10]-P[11])/Rvv - (P[9]-P[10])/Rpul #iMV-Q8-Q9
    Q11             = iMV


    # Model equations- pressure formulation +regulation
    dPdt[1]        = ElocalLV * (Q11 - Q1) + dEdtlocalLV * P[1]/ElocalLV
    dPdt[2]        = -Q2 / CAo
    dPdt[3]        = -Q3 / CsA 

    dPdt[38]       = (-P[38] + sigmaCs)/tau_Cvs
    dPdt[22]       = -Q4 - dPdt[38]; 
    dPdt[4] = ((1+(tan(P[22]/alpha2))^2)^2) / (CsV*(1-(tan(P[22]/alpha2))^2)) * ((P[3]-P[4])/P[31] - (P[4]-P[7])/RsV) -
              ((1+(tan(P[22]/alpha2))^2)^2) / (CsV*(1-(tan(P[22]/alpha2))^2)) * dPdt[38]  
    dPdt[5]        = -Q5 / CeA 
    dPdt[37]       = (-P[37] + sigmaCv)/tau_Cv 
    dPdt[24]       = -Q6 - dPdt[37]; 
    dPdt[6] = ((1+(tan(P[24]/alpha))^2)^2) / (CeV*(1-(tan(P[24]/alpha))^2)) * ((P[5]-P[6])/P[32] - iEV) -
              ((1+(tan(P[24]/alpha))^2)^2) / (CeV*(1-(tan(P[24]/alpha))^2)) * dPdt[37] + source   
    dPdt[7]        = ElocalRA * (Q1 + Q2 + Q3 + Q4 + Q5 + Q6 - Q7) + dEdtlocalRA * P[7]/ElocalRA 
    dPdt[8]        = ElocalRV * (Q7 - Q8) + dEdtlocalRV * P[8]/ElocalRV
    dPdt[9]        = -Q9 / CpulA
    dPdt[10]       = -Q10 / CpulV
    dPdt[11]       = ElocalLA * (Q8 + Q9 +Q10 - Q11) + dEdtlocalLA * P[11]/ElocalLA # 11 node 11 is the left atrium but these are the flows for hte RIGHT atrium I think 
    
    dPdt[12]       = (-P[12] + P[2] + tau_z*dPdt[2])/tau_p;     
    dPdt[13]       = (-P[13] + sigmaHTs)/tau_HTs                                     
    dPdt[14]       = (-P[14] + sigmaRsp)/tau_Rsp                                      
    dPdt[15]       = (-P[15] + sigmaRep)/tau_Rep                                     
    dPdt[16]       = (-P[16] + sigmaELV)/tau_ELV          
    dPdt[17]       = (-P[17] + sigmaERV)/tau_ERV                           
    dPdt[18]       = (-P[18] + sigmaHTv)/tau_HTv 
    dPdt[19]       = Q11 - Q1
    dPdt[20]       = -Q2
    dPdt[21]       = -Q3
    dPdt[23]       = -Q5
    dPdt[25]       = Q1 + Q2 + Q3 + Q4 + Q5 + Q6 - Q7
    dPdt[26]       = Q7 - Q8
    dPdt[27]       = -Q9
    dPdt[28]       = -Q10
    dPdt[29]       = Q8 + Q9 +Q10 - Q11
    dPdt           = dPdt';
    return P,t
end


# Functions -----------------------------------------------------------------------------
# Heaviside step function 
heaviside(x::AbstractFloat) = ifelse(x < 0, zero(x), ifelse(x > 0, one(x), oftype(x,0.5)))

# Valve function
function Valve(pressureDifference, valveResistance)
    q           = (pressureDifference./valveResistance)     .* (pressureDifference >  0) +
    (pressureDifference/1000/valveResistance)  .* (pressureDifference <= 0);
    return q
end

# Elastance function
function ShiCosineElastance(t, tauinit, tauESvalue0, tauSSvalue0, ELVmaxValue, ELVminValue, heartRate)
    t           = rem(t,60 / heartRate); #in seconds, time from 0

    tauValue    = t * heartRate / 60;
    #tauESvalue = (tauESvalue0/(60/heartRate))    *((60/heartRate) > 15/8 *tauESvalue0) + (8/15)*    ((60/heartRate)<= 15/8*tauESvalue0)   # base: 0.3 for ventricles [-]
    #tauSSvalue = (1.5*tauESvalue)   * (tauESvalue<=1.0/1.5)   + 1.0 * (tauESvalue>1.0/1.5)#1.5*tauESvalue
    tauESvalue=tauESvalue0
    tauSSvalue=tauSSvalue0
    e           = 0                                                         * (tauValue >= 0)*(tauValue < tauinit)   +
                (1-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))       *(tauValue >= tauinit)*(tauValue <= tauESvalue)  +
                (1+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))   *(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +
                0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;   
    dedtau      = 0 * (tauValue >= 0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60;
    return e1, dedt1
end

function ShiCosineElastanceATRIA(t, tauinit, tauESvalue, tauSSvalue, ELVmaxValue, ELVminValue, heartRate)
    t           = rem(t,60 / heartRate); #in seconds, time from 0

    tauValue    = t * heartRate / 60;
    e           = 0                                                         * (tauValue >= 0)*(tauValue < tauinit)   +
                (1-cos((pi*(tauValue-tauinit))/(tauESvalue-tauinit)))       *(tauValue >= tauinit)*(tauValue <= tauESvalue)  +
                (1+cos(pi*(tauValue-tauESvalue)/(tauSSvalue-tauESvalue)))   *(tauValue > tauESvalue)*(tauValue <= tauSSvalue) +
                0*(tauValue > tauSSvalue);
    e1          = 0.5 * (ELVmaxValue - ELVminValue) * e + ELVminValue;   
    dedtau      = 0 * (tauValue >= 0)*(tauValue < tauinit)  +   sin(pi*(tauValue-tauinit)/(tauESvalue-tauinit)) * pi/(tauESvalue-tauinit)*(tauValue >= tauinit)*(tauValue <= tauESvalue)    +   sin(pi*(tauESvalue-tauValue)/(tauESvalue-tauSSvalue))*pi/(tauESvalue-tauSSvalue)*(tauValue > tauESvalue)*(tauValue <= tauSSvalue)    +   0*(tauValue > tauSSvalue);
    dedt1       = 0.5 * (ELVmaxValue - ELVminValue) * dedtau * heartRate / 60;
    return e1, dedt1
end

function Averaging(time, data, t_start)
    t_end = t_start + 30
    indices = findall((time .>= t_start) .& (time .<= t_end))
    return [Statistics.mean(data[indices]), Statistics.std(data[indices])]
end

#%% Solution
delay = [2, 2, 2, 2, 2,5,5, 0.2]
initConditions   = [7.0,          7.0,        7.0,         7.0,         7.0,         7.0,        7.0,       7.0,        7.0,            7.0,         7.0,      100.0,     0.0,        0.0,       0.0,        0.0,        0.0,        0.0,     7.0*1/0.10,    7.0*0.28,  7.0*2.05,   7.0*61.11,   7.0*1.67,   7.0*50.0,   7.0*1/0.12, 7.0*1/0.06, 7.0*5.8,   7.0*25.37,   7.0*1/0.27, 0.83, 2.0, 1.5, 1.75,  0.52, 0, 0.83, 0, 0]


par = [Pn, tau_HTs, kes, gain_Rep, gain_HTs, gain_Cvs]

h(p, t)   = ones(12)*100                                                  # Constant history of P(9) 
p         = par
prob      = DDEProblem(model, initConditions, h, tspan, p; constant_lags = delay)
timeDigitMAP = range(220, stop = 740, length = 80000)
@time sol1= solve(prob, MethodOfSteps(Tsit5()), reltol = 1e-7, abstol = 1e-7, maxiters=10^6, saveat=timeDigitMAP);


timeDigitMAP = range(220, stop = 740, length = 40000)



delta_t_HR_ex = 505
delta_t_SV_ex = 505

maxHR = 1.2281
minMAP = 0.9325
minSV = 0.6186

function loss1(newp)
    newp[1] = round.(newp[1]; digits=0)
    newp[2] = round.(newp[2]; digits=0)
    newp[3] = round.(newp[3]; digits=2)
    newp[4] = round.(newp[4]; digits=2)
    newp[5] = round.(newp[5]; digits=2)
    newp[6] = round.(newp[6]; digits=0)
    t11=0
    prob1 = remake(prob; p = newp)
    h(p, t)   = ones(12)*100 
    t11=0
    sol= solve(prob1, MethodOfSteps(Tsit5()), reltol = 1e-7, abstol = 1e-7, saveat=timeDigitMAP)
    if (sol.retcode == ReturnCode.Success) 
        COpksMAX, COvalsMAX = findmaxima(sol[19,:]); 
        COpksMIN, COvalsMIN = findminima(sol[19,:]);
        if length(COvalsMAX)>=length(COvalsMIN)
            relCHANGEsv = (COvalsMAX[1:length(COvalsMIN)] .- COvalsMIN[1:length(COvalsMIN)]) ./ (COvalsMAX[1] .- COvalsMIN[1])
            relCHANGEhr = (60 ./ sol[30, COpksMAX[1:length(COvalsMIN)]]) ./ (60 ./ sol[30, COpksMAX[1]])
            timeVecCO = (sol.t[COpksMAX[1:length(COvalsMIN)]]) 

        else
            STROKE_VOLUME = COvalsMAX[1:length(COvalsMAX)] .- COvalsMIN[1:length(COvalsMAX)]
            HEART_RATE = 60 ./ sol[30, COpksMAX[1:length(COvalsMAX)]]
            relCHANGEhr = HEART_RATE /HEART_RATE[1]
            relCHANGEsv = STROKE_VOLUME ./ STROKE_VOLUME[1]
            timeVecCO = (sol.t[COpksMAX[1:length(COvalsMAX)]]) 
        end

        #MAP
        MAPpksMAX, MAPvalsMAX = findmaxima(sol[2,:])
        MAPpksMIN, MAPvalsMIN = findminima(sol[2,:])
        if length(MAPvalsMAX) < length(MAPvalsMIN)
            MEAN_ARTERIAL_PRESSURE = (MAPvalsMIN[1:length(MAPvalsMAX)] .+ 1/3*(MAPvalsMAX-MAPvalsMIN[1:length(MAPvalsMAX)]))  
            timeVecMAP = (sol.t[MAPpksMAX])
        else
            MEAN_ARTERIAL_PRESSURE = (MAPvalsMIN[1:length(MAPvalsMIN)] .+ +1/3*(MAPvalsMAX[1:length(MAPvalsMIN)]-MAPvalsMIN)) 
            timeVecMAP = (sol.t[MAPpksMIN])
        end
        MAP = MEAN_ARTERIAL_PRESSURE ./ MEAN_ARTERIAL_PRESSURE[1]
        
        averaged_HR=zeros(16)
        averaged_SV=zeros(16)
        averaged_time=zeros(16)
        n_window=16
        for i in 1:n_window
            averaged_HR[i] = Averaging(timeVecCO, relCHANGEhr, (timeVecCO[1] + 30 * (i-1)))[1]
            averaged_time[i] = Averaging(timeVecCO, timeVecCO, timeVecCO[1] + 30 * (i-1))[1]
            averaged_SV[i] = Averaging(timeVecCO, relCHANGEsv, timeVecCO[1] + 30 * (i-1))[1]
        end
        averaged_MAP=zeros(16)
        averaged_timeMAP=zeros(16)
        for i in 1:n_window
            averaged_MAP[i] = Averaging(timeVecMAP, MAP, timeVecMAP[1] + 30 * (i-1))[1]
            averaged_timeMAP[i] = Averaging(timeVecMAP, timeVecMAP, timeVecMAP[1] + 30 * (i-1))[1]
        end
        
        delta_t_HR_sim = averaged_time[argmax(averaged_HR)]#-sol.t[1]
        delta_t_SV_sim = averaged_time[argmin(averaged_SV)]#-sol.t[1]
        loss = 1*((delta_t_HR_sim-delta_t_HR_ex)/delta_t_HR_ex)^2 + 1*((delta_t_SV_sim-delta_t_SV_ex)/delta_t_SV_ex)^2 + 1*((maximum(averaged_HR)-maxHR)/maxHR)^2 + 1*((minimum(averaged_SV)-minSV)/minSV)^2 + 1*((minimum(averaged_MAP)-minMAP)/minMAP)^2
        ABC = [loss, newp[1], newp[2], newp[3], newp[4], newp[5], newp[6]]
        println(ABC)
        return  loss
    else
        return Inf
    end
end


using Optimization, OptimizationOptimJL, OptimizationBBO, Optim

# # # #Optimization problem setup
adtype = Optimization.AutoForwardDiff()
Pn, tau_HTs, kes, gain_Rep, gain_HTs, gain_Cvs = p 
pguess = [92.0, 2.0, 0.0675, 0.530, -0.13, -265.4]
optf = OptimizationFunction((x, _) -> loss1(x), Optimization.AutoForwardDiff())       
optprob = OptimizationProblem(optf, pguess, lb=[  85.0, 1.0, 0.05, 0.5, -0.60, -270.0],  
                                            ub=[  95.0, 60.0, 0.15, 3.00, -0.10, -70.0])


@time pfinal = solve(optprob, BBO_adaptive_de_rand_1_bin_radiuslimited() , maxiters = 35000, PopulationSize=120) #TargetFitnesss=100000 #SAMIN is ok


A=[ pfinal.u, pfinal.objective, pfinal.stats.iterations, pfinal.stats.time, pfinal.stats.fevals, pfinal.stats.gevals, pfinal.stats.hevals]

using DelimitedFiles
writedlm( "int_35k_120_r$N.csv",  A, ',')

